peso = float(input("Insira seu peso: "))
altura = float(input("Insira sua altura: "))

imc = peso / (altura * altura)

print(f"Seu IMC é: {imc:.2f}")