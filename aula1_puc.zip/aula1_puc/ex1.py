anoNascimento = int(input("Insira seu ano de nascimento"))

idade = 2025 - anoNascimento

print("Sua idade é: " + str(idade))