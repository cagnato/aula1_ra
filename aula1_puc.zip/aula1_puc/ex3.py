celsius = int(input("Insira a temperatura em celsius: "))

conversao = (celsius * 9/5) + 32

print("A temperatura informada ficará: " + str(conversao), "após a conversão")