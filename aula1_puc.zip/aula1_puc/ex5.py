idade = int(input("Insira sua idade: "))

conversao = idade * 12

print("Sua idade em meses é: " + str(conversao))