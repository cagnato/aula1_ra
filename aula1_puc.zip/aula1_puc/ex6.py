kg = float(input("Insira quantos quilos deseja comprar: "))

preco = 2.5 * kg

print("O preço do produto é: " + str(preco))