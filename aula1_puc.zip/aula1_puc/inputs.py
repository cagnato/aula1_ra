nome = input("Insira seu nome: ")

print ("Seu nome é : " + nome, "\n") 

cpf = input("Insira seu cpf: ")
 
print ("Seu cpf é : " + cpf, "\n")

telefone = input("Insira seu Telefone: ")
 
print ("Seu telefone é : " + telefone, "\n")

ano_nasc = int(input("Insira seu ano de nascimento: "))
 
print ("Seu ano de nascimento é : " + str(ano_nasc), "\n")