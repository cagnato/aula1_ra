num_carros = int(input("Insira quantos carros deseja: "))
preco = 100
locacao_carro = (num_carros * preco)
print ("O preço total é: " + str(locacao_carro))
